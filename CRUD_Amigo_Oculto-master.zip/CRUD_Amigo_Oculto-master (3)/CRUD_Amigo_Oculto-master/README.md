Este repositório é referente ao projeto feito na disciplina de Algoritmos e Estruturas de Dados III (AEDs-III), na Pontifícia Universidade Católica de Minas Gerais (PUC Minas), no primeiro semestre de 2020.

O projeto tem como objetivo final o desenvolvimento de um sistema CRUD (Create, Read, Update, Delete) baseado em arquivos.
O sistema implementado será um sistema de Amigo Oculto.


O projeto é dividido em 11 partes:
	Parte 01 - Usuários
	Parte 02 - CRUD
	Parte 03 - Acesso
	Parte 04 - Sugestões
	Parte 05 - Grupos
	Parte 06 - Convites
	Parte 07 - Inscrição
	Parte 08 - Participantes
	Parte 09 - Participação
	Parte 10 - Mensagens
	Parte 11 - Sorteio

A data prevista para a entrega do projeto (completo) é: 20/05/2020
